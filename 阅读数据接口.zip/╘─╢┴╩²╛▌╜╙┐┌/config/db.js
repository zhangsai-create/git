const config = {
  host: 'localhost',
  user: 'txt',
  passowrd: '123456789',
  database: 'db_yuedu'
}
module.exports = config