
2.0.0 / 2016-04-09
==================

  * Add `identity` support #14
  * Remove node v0.8 support

1.0.2 / 2014-06-13
==================

  * Fix specifying encoding in `options`

1.0.1 / 2014-04-24
==================

  * Add 415 status code to unsupported content encodings

1.0.0 / 2014-04-24
==================

  * Initial release
