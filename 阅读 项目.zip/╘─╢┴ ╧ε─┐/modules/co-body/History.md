
4.2.0 / 2016-05-05
==================

  * test: test on node 4, 5, 6
  * feat: Added support for request body inflation

4.1.0 / 2016-05-05
==================

  * feat: form parse support custom qs module

4.0.0 / 2015-08-15
==================

  * Switch to Promises instead of thunks

3.1.0 / 2015-08-06
==================

 * travis: add v2, v3, remove 0.11
 * add custom types options
 * use type-is

3.0.0 / 2015-07-25
==================

 * Updated dependencies. Added qs options support via queryString option key. (@yanickrochon)
   * upgrade qs@4.0.0, raw-body@2.1.2

2.0.0 / 2015-05-04
==================

  * json parser support strict mode

1.2.0 / 2015-04-29
==================

 * Add JSON-LD as known JSON-Type (@vanthome)

1.1.0 / 2015-02-27
==================

 * Fix content-length zero should not parse json
 * Bump deps, qs@~2.3.3, raw-body@~1.3.3
 * add support for `text/plain`
 * json support for `application/json-patch+json`, `application/vnd.api+json` and `application/csp-report`
