
1.0.1 / 2018-07-18
==================

**others**
  * [[`88c57c0`](http://github.com/node-modules/cache-content-type/commit/88c57c0bd571da12d7917ae15ad67f02b7b5eabe)] - chore: support node 6 (dead-horse <<dead_horse@qq.com>>)

1.0.0 / 2018-07-11
==================

**features**
  * [[`ecb6476`](http://github.com/node-modules/cache-content-type/commit/ecb6476da4a714246f12a86c191dc05aad42e806)] - feat: cache result of mimeTypes.contentType (dead-horse <<dead_horse@qq.com>>),fatal: No names found, cannot describe anything.

**others**

