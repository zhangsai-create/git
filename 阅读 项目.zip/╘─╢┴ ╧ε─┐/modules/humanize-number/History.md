
0.0.2 / 2013-11-19
==================

  * package: add "component" section
  * package: add repository field to readme
  * add docs

0.0.1 / 2012-11-06
==================

  * initial commit
