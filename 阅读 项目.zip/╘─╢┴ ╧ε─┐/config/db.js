const config = {
  host: 'localhost',
  user: 'demo',
  passowrd: '123456',
  database: 'yuedu'
}
module.exports = config