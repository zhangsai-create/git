// 点击对应列表项跳转
$("#all-con").on("click","a",()=>{
    console.log($("this"))
    console.log($(".a-c-title"))
})